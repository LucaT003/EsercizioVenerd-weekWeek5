package com.epicode.gestione.models;

public enum Tipo {
	PRIVATO, OPENSPACE, SALARIUNIONI
}
